#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "table.h"

void table_ajouter(Symbole **table, const char *nom) {
    if (table_existe(*table, nom)) return;

    Symbole *s = malloc(sizeof(Symbole));
    s->nom = strdup(nom);
    s->suivant = *table;
    *table = s;
}

int table_existe(Symbole *table, const char *nom) {
    while (table) {
        if (strcasecmp(table->nom, nom) == 0)
            return 1;
        table = table->suivant;
    }
    return 0;
}

void table_afficher(Symbole *table) {
    while (table) {
        printf("- %s\n", table->nom);
        table = table->suivant;
    }
}

void table_liberer(Symbole *table) {
    Symbole *tmp;
    while (table) {
        tmp = table;
        table = table->suivant;
        free(tmp->nom);
        free(tmp);
    }
}
