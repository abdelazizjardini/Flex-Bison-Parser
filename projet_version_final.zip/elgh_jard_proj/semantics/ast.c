#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

AST *nvNoeud(ASTType type, AST *g, AST *d) {
    AST *n = malloc(sizeof(AST));
    n->type = type;
    n->gauche = g;
    n->droite = d;
    n->suivant = NULL;
    n->nom = NULL;
    return n;
}

AST *nvFeuille(ASTType type, char *nom) {
    AST *n = nvNoeud(type, NULL, NULL);
    if (nom) n->nom = strdup(nom);
    return n;
}

void ajouterSuivant(AST *parent, AST *enfant) {
    if (!parent) return;
    AST *tmp = parent;
    while (tmp->suivant) tmp = tmp->suivant;
    tmp->suivant = enfant;
}

void afficherAST(AST *n, int indent) {
    if (!n) return;

    for (int idx = 0; idx < indent; idx++) printf("  ");

    switch (n->type) {
        case AST_PROGRAMME: printf("PROGRAMME\n"); break;
        case AST_ALPHABET: printf("ALPHABET\n"); break;
        case AST_ETATS: printf("ETATS\n"); break;
        case AST_INITIAL: printf("INITIAL\n"); break;
        case AST_FINAUX: printf("FINAUX\n"); break;
        case AST_TRANSITION: printf("TRANSITION\n"); break;
        case AST_LISTE: printf("LISTE\n"); break;
        case AST_ID: printf("ID(%s)\n", n->nom); break;
        case AST_SYMBOLE: printf("SYM(%s)\n", n->nom); break;
        case AST_CHAINE: printf("CHAINE(%s)\n", n->nom); break;
        case AST_COMMAND: printf("COMMAND\n"); break;
    }

    afficherAST(n->gauche, indent + 1);
    afficherAST(n->droite, indent + 1);
    afficherAST(n->suivant, indent);
}

void libererAST(AST *n) {
    if (!n) return;
    libererAST(n->gauche);
    libererAST(n->droite);
    libererAST(n->suivant);
    if (n->nom) free(n->nom);
    free(n);
}
