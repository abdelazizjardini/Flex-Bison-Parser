#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantic.h"
#include "ast.h"

// Helper to check if a string exists in a list (AST_LISTE)
int existeDansListe(AST *liste, const char *val) {
    if (!liste) return 0;
    
    // Iterate through linked list of nodes
    AST *curr = liste;
    while (curr) {
        if (curr->type == AST_ID || curr->type == AST_SYMBOLE || curr->type == AST_CHAINE) {
            if (curr->nom && strcmp(curr->nom, val) == 0) return 1;
        }
        // Also check recursive lists if structure is nested (though usually flat)
        if (curr->gauche && existeDansListe(curr->gauche, val)) return 1;
        
        curr = curr->suivant;
    }
    return 0;
}

// Helper: Extract specific section from program root
AST* getSection(AST *root, ASTType type) {
    if (!root) return NULL;
    AST *curr = root->gauche; // sections list
    while (curr) {
        if (curr->type == type) return curr;
        // If it's a list containing the section
        if (curr->gauche && curr->gauche->type == type) return curr->gauche;
        curr = curr->suivant;
    }
    return NULL;
}

int verifierSemantique(AST *root) {
    printf("--- Verifications Semantiques ---\n");
    if (!root) return 0;

    // 1. Gather sections
    AST *prog = root;
    AST *sections = prog->gauche;
    
    AST *alphabet = NULL;
    AST *etats = NULL;
    AST *initial = NULL;
    AST *finaux = NULL;
    AST *transitions = NULL;

    AST *curr = sections;
    while (curr) {
        if (curr->type == AST_ALPHABET) alphabet = curr;
        else if (curr->type == AST_ETATS) etats = curr;
        else if (curr->type == AST_INITIAL) initial = curr;
        else if (curr->type == AST_FINAUX) finaux = curr;
        else if (curr->type == AST_TRANSITION) transitions = curr;
        else if (curr->type == AST_LISTE && curr->gauche) {
             // Only drill down if it is a generic LIST container (if used)
             if (curr->gauche->type == AST_ALPHABET) alphabet = curr->gauche;
             else if (curr->gauche->type == AST_ETATS) etats = curr->gauche;
             else if (curr->gauche->type == AST_INITIAL) initial = curr->gauche;
             else if (curr->gauche->type == AST_FINAUX) finaux = curr->gauche;
             else if (curr->gauche->type == AST_TRANSITION) transitions = curr->gauche;
        }
        curr = curr->suivant;
    }

    int valide = 1;

    // 2. Validate Initial State
    if (initial) {
        char *initName = initial->nom;
        if (!existeDansListe(etats ? etats->gauche : NULL, initName)) {
            printf("[ERREUR] L'etat initial '%s' n'est pas declare dans les etats.\n", initName);
            valide = 0;
        }
    } else {
        printf("[ERREUR] Pas d'etat initial defini.\n");
        valide = 0;
    }

    // 3. Validate Final States
    if (finaux && finaux->gauche) {
        AST *fState = finaux->gauche;
        while (fState) {
            if (!existeDansListe(etats ? etats->gauche : NULL, fState->nom)) {
                 printf("[ERREUR] L'etat final '%s' n'est pas declare dans les etats.\n", fState->nom);
                 valide = 0;
            }
            fState = fState->suivant;
        }
    }

    // 4. Validate Transitions
    // Transitions logic depends on how AST calls them. Assuming transitions list is in `transitions->gauche`
    if (transitions) {
        AST *trans = transitions->gauche; // List of transitions
        while (trans) { 
             // trans structure: gauche=ID(source), droite=AST_TRANSITION(sym, dest) OR custom structure
             // Based on likely AST construction from parser:
             // transition: ID : SYM -> ID
             // Let's assume we store it flat or structured. 
             // We'll see AST_TRANSITION nodes usually.
             
             // Currently generic traversal:
             if (trans->type == AST_TRANSITION) {
                  // Expecting: nom=symbole, gauche=ID(src), droite=ID(dest)
                  char *src = trans->gauche ? trans->gauche->nom : NULL;
                  char *dest = trans->droite ? trans->droite->nom : NULL;
                  char *sym = trans->nom;

                  if (src && !existeDansListe(etats ? etats->gauche : NULL, src)) {
                      printf("[ERREUR] Transition: Etat source '%s' inconnu.\n", src);
                      valide = 0;
                  }
                  if (dest && !existeDansListe(etats ? etats->gauche : NULL, dest)) {
                       printf("[ERREUR] Transition: Etat destination '%s' inconnu.\n", dest);
                       valide = 0;
                  }
                  if (sym && !existeDansListe(alphabet ? alphabet->gauche : NULL, sym)) {
                       printf("[ERREUR] Transition: Symbole '%s' hors alphabet.\n", sym);
                       valide = 0;
                  }
             }
             trans = trans->suivant;
        }
    }
    
    if (valide) printf("Automate sémantiquement VALIDE.\n");
    else printf("Automate sémantiquement INVALIDE.\n");

    return valide;
}

// Find transition for (state, symbol)
// Returns name of next state or NULL
char* getNextState(AST *transitions, const char *currentState, const char *symbol) {
    if (!transitions) return NULL;
    AST *t = transitions->gauche;
    while (t) {
        if (t->type == AST_TRANSITION) {
             char *src = t->gauche ? t->gauche->nom : NULL;
             char *sym = t->nom;
             char *dest = t->droite ? t->droite->nom : NULL;
             
             if (src && sym && strcmp(src, currentState) == 0 && strcmp(sym, symbol) == 0) {
                 return dest;
             }
        }
        t = t->suivant;
    }
    return NULL;
}

void executerAutomate(AST *root, char *mot) {
    printf("--- Execution mot: \"%s\" ---\n", mot);
    
    // Find semantics again
    AST *sections = root->gauche; 
    AST *initial = NULL;
    AST *finaux = NULL;
    AST *transitions = NULL;

    AST *curr = sections;
    while (curr) {
        if (curr->type == AST_ALPHABET) {} // skip
        else if (curr->type == AST_INITIAL) initial = curr;
        else if (curr->type == AST_FINAUX) finaux = curr;
        else if (curr->type == AST_TRANSITION) transitions = curr;
        else if (curr->type == AST_LISTE && curr->gauche) {
             if (curr->gauche->type == AST_INITIAL) initial = curr->gauche;
             else if (curr->gauche->type == AST_FINAUX) finaux = curr->gauche;
             else if (curr->gauche->type == AST_TRANSITION) transitions = curr->gauche;
        }
        curr = curr->suivant;
    }

    if (!initial) {
        printf("Erreur: Pas d'etat initial.\n");
        return;
    }

    char *currentState = initial->nom;
    printf("Etat depart: %s\n", currentState);

    int len = strlen(mot);
    for (int i = 0; i < len; i++) {
        char symStr[2] = { mot[i], '\0' };
        
        char *next = getNextState(transitions, currentState, symStr);
        if (!next) {
            printf("Blocage: Pas de transition pour (%s, %s)\n", currentState, symStr);
            printf("Resultat: REJETE\n");
            return;
        }
        printf("Transition: %s --(%s)--> %s\n", currentState, symStr, next);
        currentState = next;
    }

    // Check if final
    int isFinal = existeDansListe(finaux ? finaux->gauche : NULL, currentState);
    if (isFinal) {
        printf("Etat final atteint: %s\n", currentState);
        printf("Resultat: ACCEPTE\n");
    } else {
        printf("Arret sur etat NON final: %s\n", currentState);
        printf("Resultat: REJETE\n");
    }
}
