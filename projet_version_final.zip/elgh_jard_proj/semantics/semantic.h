#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "ast.h"

// Checks validity of the automaton (states, alphabet, transitions)
int verifierSemantique(AST *root);

// Executes the automaton on a given word
// Returns 1 if accepted, 0 if rejected
void executerAutomate(AST *root, char *mot);

#endif // SEMANTIC_H
