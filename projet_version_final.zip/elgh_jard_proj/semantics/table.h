#ifndef TABLE_H
#define TABLE_H


typedef struct Symbole {
    char *nom;
    struct Symbole *suivant;
} Symbole;

void table_ajouter(Symbole **table, const char *nom);
int table_existe(Symbole *table, const char *nom);
void table_afficher(Symbole *table);
void table_liberer(Symbole *table);



#endif // TABLE_H
