#ifndef AST_H
#define AST_H

typedef enum {
    AST_PROGRAMME,
    AST_ALPHABET,
    AST_ETATS,
    AST_INITIAL,
    AST_FINAUX,
    AST_TRANSITION,
    AST_LISTE,
    AST_ID,
    AST_SYMBOLE,
    AST_CHAINE,
    AST_COMMAND
} ASTType;

typedef struct AST {
    ASTType type;
    char *nom;
    struct AST *gauche;
    struct AST *droite;
    struct AST *suivant;
} AST;

AST *nvNoeud(ASTType type, AST *g, AST *d);
AST *nvFeuille(ASTType type, char *nom);
void ajouterSuivant(AST *parent, AST *enfant);
void afficherAST(AST *n, int indent);
void libererAST(AST *n);

#endif // AST_H
